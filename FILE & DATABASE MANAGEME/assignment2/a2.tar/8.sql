prompt Question 8 - yyin
