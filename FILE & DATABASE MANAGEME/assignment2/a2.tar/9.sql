prompt Question 9 - yyin
